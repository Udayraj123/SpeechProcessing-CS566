#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<sstream> // for digit in filename 
#include <iomanip> // for setprecision
#include<cmath> //for abs
using namespace std;

void writeLines(ofstream &fObjOut,vector<string> &lines){
	for (int i = 0; i < lines.size(); ++i) {
		fObjOut << lines[i]; 
	}
}
void getLines(vector<string>& linesVec_, ifstream& inFile_)
{
	string line;
	while (getline(inFile_, line))
	{
		linesVec_.push_back(line);
	}
}

float calcZCR(vector<int> &samples, int s, int e){
	int prev=0,zcr=0;
	for (int i = s; i < e; ++i) {
		if(samples[i]==0){
			if(prev * samples[i+1]<0)zcr++;
		}
		else{
			prev=samples[i];//update only if nonzero
			if(samples[i-1] * samples[i]<0)zcr++;
		}
	}
	return 100 * zcr/(float)(e-s);
}
void writeSample(ofstream &fObjOut,vector<int> &samples, int s, int e){
	fObjOut<<"SAMPLES: "<<(e-s+1)<<endl;
	fObjOut<<"BITSPERSAMPLE:	16"<<endl;
	fObjOut<<"CHANNELS:	1"<<endl;
	fObjOut<<"SAMPLERATE:	16000"<<endl;
	fObjOut<<"NORMALIZED:	FALSE"<<endl;
	// cout<<s<<" , "<<e<<endl;
	for (int i = s; i <= e; ++i) {
		// cout<<samples[i]<<endl;
		fObjOut<<samples[i]<<endl;
	}
}

/*

Program to classify input voices as One or Six
This also creates smaller clips of the utterances(based on a threshold)

Input : A File - all1s.txt or all6s.txt (modify the variable 'digit' for this)
Output: ONE or SIX

*/

int main(){
	
// Config
	// string digit="6"; //for all6s.txt
	string digit="1"; //for all1s.txt
	
	// Parameters From Initial Analysis
	int M_SILENCE=150,
	windowSize=3790,
	DC_SHIFT=0,
	N_AMP=5000, //N_AMP should be high, else it may cause data loss due to rounding
	ZCR_THR=10, // In percentage
	N_CLIPS_LIMIT=11 // to avoid too many file writes
	;
	float SAMPLERATE=16000;
	//take file input
	ifstream fObjData("data/all"+digit+"s.txt");
	vector <string> lines;
	getLines(lines,fObjData);

	// declarations
	int N_SAMPLES=lines.size()-5;
	vector<int> samples;
	int x,maxX=0;

	//Read line by line, do DC shift as well as load the samples
	for (int i = 0; i < N_SAMPLES; ++i) {
		sscanf(&lines[i+5][0],"%d",&x);
		x-=DC_SHIFT;
		samples.push_back(x);
		maxX=max(maxX,(int)abs(x));
	}
	//Normalize
	float N_fac=N_AMP/(float)maxX;
	for (int i = 0; i < N_SAMPLES; ++i)
		samples[i] *= N_fac;
	

	vector<bool> blurred_samples(N_SAMPLES,false);
	vector< pair<int,int> > clips;
	// Apply M_SILENCE for windowed threshold
	long long int windowSum=0;
	for (int i = 0; i < N_SAMPLES; ++i) {
		x=abs(samples[i]);
		windowSum += x;
		if(i>windowSize){
			windowSum -= abs(samples[i-windowSize]);
			// should make mid point rather than end.
			if((windowSum/(float)windowSize)>M_SILENCE)
				blurred_samples[i-windowSize/2]=true;
		}
		// else default is false
	}

	// Detect clips using applied threshold
	bool prev=blurred_samples[0];
	int start=0;
	for (int i = 1; i < N_SAMPLES; ++i) {
		if(prev != blurred_samples[i]){
			if(!start){
				start=i;
			}else{
				//end
				clips.push_back(make_pair(start,i));
				start=0;
			}
		}
		prev=blurred_samples[i];
	}
	float zcr;int num_samples;
	if(clips.size() > N_CLIPS_LIMIT){
		cout<<"Error: too many clips found: "<<clips.size()<<endl;
		cout<<"Either increase limit or resolve the issue\n";
		return 1;
	}
	std::ostringstream filename;
	// For each clip perform the calculations
	for (int i = 0; i < clips.size(); ++i) {
		cout<<"Clip "<<i<<":";
		num_samples=(clips[i].second-clips[i].first);
		// cout << " ["<<clips[i].first<<","<<clips[i].second<<"] = "<<num_samples<<" samples, ";
		cout << " Duration: "<<std::setprecision(3)<<(num_samples/SAMPLERATE)<<"s, ";
		zcr=calcZCR(samples,clips[i].first,clips[i].second);
		cout<<"ZCR = "<<std::setprecision(3)<<zcr<<"% \t";
		if(zcr < ZCR_THR)
			cout <<"= ONE\n";
		else
			cout <<"= SIX\n";
		//write cropped sample into new file		
		filename.str(std::string());// clear the stream;
		filename<<"150101021_"<<digit<<"_"<<i<<".txt";
		ofstream fObjOut(filename.str());
		writeSample(fObjOut,samples,clips[i].first,clips[i].second);
		fObjOut.close();
	}
	fObjData.close();
	return 0;
}