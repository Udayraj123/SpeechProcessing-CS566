Solution to Problem 3 implemented

## How to run the code
1. Compile HMM.cpp 
	Important: use the '-std=c++11' option else it wont compile
	g++ -std=c++11 -o HMM.exe HMM.cpp

2. Run HMM.exe
	HMM.exe  
