## Description
Applying K means and LBG methods on a universe file generated from vowel utterances.

## How to run the code
1. Prepare universe.txt file:
 a) Make sure to modify config.h has SAVE_INTO_UNIVERSE set to 1 and CURR_DIR set to your current directory.
 b) (optional) Put your vowel recordings named a.txt, b.txt, etc in the directory 'input_data/'
 	and regenerate universe.txt file:
		g++ -std=c++11 -o process_vowels process_vowels.cpp
		process_vowels.exe
	It will generate 'coeffs/universe.txt' file.
 c) Run K Means to obtain cluster points with labels and the codebook.
		g++ -std=c++11 -o k_means k_means.cpp
		k_means.exe
	To change size of codebook, you can modify CODEBOOK_SIZE parameter. 
	To change max iterations for k means, change KMEANS_ITERATIONS.
 c) Run LGB to obtain cluster points with labels and the codebook.
		g++ -std=c++11 -o LGB LGB.cpp
		LGB.exe
